Judul Game : Tetris

Nama Kelompok :

1. Nurul Ilma Asyuriah
2. Rahmat Ansori
3. Fifi Maghfirotun Nisa

Note : Dibuat di Linux Ubuntu, tidak untuk dijalankan di Windows
